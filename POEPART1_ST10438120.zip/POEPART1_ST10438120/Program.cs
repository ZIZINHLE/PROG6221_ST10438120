﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.IO; // Needed for file path handling

namespace CybersecurityAwarenessBot
{
    class Program
    {
        static void Main(string[] args)
        {
            PlayVoiceGreeting();
            DisplayAsciiArt();
            string name = GetUserName();

            SimulateTyping($"\n🔐 {name}, you can ask me anything about staying safe online. Here are some suggestions on what you can ask me:\n", 40);
            DisplaySuggestedQuestions();

            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.Write("\n💬 What would you like to know? (type 'exit' to quit): ");
                string userInput = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(userInput))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("⚠️ Please enter something.");
                    continue;
                }

                if (userInput.ToLower().Contains("exit"))
                {
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine($"\n👋 Goodbye {name}, and remember—stay safe online!");
                    break;
                }

                string response = GetBotResponse(userInput, name);
                SimulateTyping($"🤖 {response}", 40);
                Console.ResetColor();
            }
        }

        static void PlayVoiceGreeting()
        {
            try
            {
                string audioPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "VoiceGreeting.wav");

                if (File.Exists(audioPath))
                {
                    SoundPlayer player = new SoundPlayer("C:\\Users\\RC_Student_lab\\source\\repos\\CybersecurityAwarenessBot\\Properties\\VoiceGreeting.wav");
                    player.PlaySync(); // Waits until done playing
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("[Audio file not found: VoiceGreeting.wav]");
                    Console.ResetColor();
                }
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"[Error playing audio: {ex.Message}]");
                Console.ResetColor();
            }
        }

        static void DisplayAsciiArt()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(@"
   ____ _           _   _           _   
  / ___| |__   __ _| |_| |__   ___ | |_ 
 | |   | '_ \ / _` | __| '_ \ / _ \| __|
 | |___| | | | (_| | |_| | | | (_) | |_ 
  \____|_| |_|\__,_|\__|_| |_|\___/ \__| 
                                     
       Welcome to the Cybersecurity Awareness Bot!
");
            Console.ResetColor();
        }

        static string GetUserName()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("\n👤 What's your name? ");
            string name = Console.ReadLine();

            while (string.IsNullOrWhiteSpace(name))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("⚠️ Name can't be blank. Please enter your name: ");
                name = Console.ReadLine();
            }

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"\n🌟 Hello, {name}! Let's boost your cyber-smarts.\n");
            Console.ResetColor();
            return name;
        }

        static string GetBotResponse(string input, string name)
        {
            input = input.ToLower();

            // Password Security
            if (input.Contains("what makes a strong password"))
                return $"A strong password should be long, unique, and include a mix of uppercase, lowercase, numbers, and symbols, {name}. 🔑 Example: T!me2S@fe#2025";

            if (input.Contains("how often should i change my password"))
                return $"It’s a good practice to change your passwords every 3 to 6 months, {name}, and never reuse passwords across sites!";

            if (input.Contains("password manager"))
                return $"A password manager securely stores your passwords, {name}, so you don’t have to remember them all. It's safer than using the same one for multiple accounts.";

            // Phishing & Scams
            if (input.Contains("what is phishing"))
                return $"Phishing is when attackers pretend to be trusted entities to trick you into sharing personal information, {name}. Be careful with suspicious emails or links.";

            if (input.Contains("how can i tell if an email is a scam"))
                return $"Look for spelling mistakes, strange sender addresses, or urgent requests for personal information. If it looks fishy, don’t click, {name}! 🚨";

            // Safe Browsing
            if (input.Contains("what's the difference between http and https"))
                return $"HTTPS is the secure version of HTTP, {name}. The 'S' stands for 'Secure,' meaning the website encrypts your data for privacy.";

            if (input.Contains("how do i know if a website is safe"))
                return $"Check for a padlock 🔒 in the address bar and ensure the URL starts with 'https' before entering any sensitive information, {name}.";

            // Two-Factor Authentication
            if (input.Contains("what is two-factor authentication"))
                return $"Two-factor authentication (2FA) adds an extra layer of security, {name}, by requiring something you know (password) and something you have (like your phone) to log in.";

            // Malware & Device Security
            if (input.Contains("what is malware"))
                return $"Malware is malicious software, {name}, designed to damage or steal data from your device. Always keep your software updated and install antivirus software!";

            if (input.Contains("how can i secure my phone"))
                return $"To secure your phone, {name}, use a passcode, enable two-factor authentication, and only download apps from trusted sources like the App Store or Google Play.";

            // Digital Footprint & Privacy
            if (input.Contains("what is digital footprint"))
                return $"Your digital footprint is the trail of data you leave online, {name}. This includes social media posts, search history, and other personal information shared digitally.";

            if (input.Contains("how do i protect my privacy online"))
                return $"Use strong passwords, avoid sharing too much personal info on social media, and use tools like VPNs to hide your IP address when browsing, {name}.";

            // Fun
            if (input.Contains("who created you"))
                return $"I was created by zizinhle for a school project, {name}, to help you stay safe online! 😊";

            if (input.Contains("can you test my knowledge"))
                return $"Sure! Let's see how well you know cybersecurity, {name}. I'll ask a few questions. Are you ready?";

            return $"Hmm, I didn’t quite catch that, {name}. Could you try asking in another way?";
        }

        static void DisplaySuggestedQuestions()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(@"
Here are some suggested questions you can ask me:
- What makes a strong password?
- How can I tell if an email is a scam?
- What's the difference between HTTP and HTTPS?
- How do I secure my phone?
- What is malware?
- What is two-factor authentication?
- How do I protect my privacy online?
- Can you test my knowledge of cybersecurity?

Feel free to ask me anything related to online safety, and I’ll be happy to help!
");
            Console.ResetColor();
        }

        static void SimulateTyping(string text, int delay = 30)
        {
            foreach (char c in text)
            {
                Console.Write(c);
                Thread.Sleep(delay);
            }
            Console.WriteLine();
        }
    }
}
